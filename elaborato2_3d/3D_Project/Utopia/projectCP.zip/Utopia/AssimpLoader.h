#pragma once
#include "Strutture.h"

bool loadAssImp(const char* path,vector<MeshObj> &mesh);